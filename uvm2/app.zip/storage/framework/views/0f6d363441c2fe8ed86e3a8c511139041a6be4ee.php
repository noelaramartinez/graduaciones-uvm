<?php $__env->startSection('title', 'UVM'); ?>

<?php $__env->startSection('sidebar'); ?>
##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

<br />
<br />
<br />
<br />
<br />

<div class="container text-center">
    <div class="row ">
        <div class="col-4 mx-auto">
            <div class="card">
                <form action="" method="POST">
                    <img src="<?php echo e(asset('images/uvm_logo.png')); ?>" alt="BannerHome_Compartamos" />
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                        Please fix the following errors
                    </div>
                    <?php endif; ?>
                    <?php echo csrf_field(); ?>

                    <div class="col-auto">
                        <label class="sr-only" for="inlineFormInputGroup">Usuario</label>
                        <div class="input-group mb-2">
                            <div class="input-group-prepend">
                                <div class="input-group-text">Usuario</div>
                            </div>
                            <input type="text" class="form-control" id="usuario" placeholder="No. de Cuenta ó E-mail">
                        </div>
                    </div>

                    <div class="col-auto">
                        <label class="sr-only" for="inlineFormInputGroup">Password</label>
                        <div class="input-group mb-2">
                            <div class="input-group-prepend">
                                <div class="input-group-text">Password</div>
                            </div>
                            <input type="password" class="form-control" id="password" placeholder="******">
                        </div>
                    </div>
                    <br/>
                    <button type="submit" class="btn btn-danger">Log In</button>
                    <br/>
                </form>
            </div>
        </div>
    </div>

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>