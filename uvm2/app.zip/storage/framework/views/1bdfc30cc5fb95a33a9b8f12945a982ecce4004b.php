<?php $__env->startSection('title', 'UVM'); ?>

<?php $__env->startSection('sidebar'); ?>
##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <p>DENTRO DE PAGINA DE VISTA DE REFERENCIA </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>