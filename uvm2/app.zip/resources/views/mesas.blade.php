@extends('index')

@section('title', 'UVM')

@section('sidebar')
@parent
@endsection

@section('contenido')

    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <p>DENTRO DE PAGINA DE VISTA DE LAS MESAS</p>
@endsection