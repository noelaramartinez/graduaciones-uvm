@extends('index')

@section('title', 'UVM')

@section('sidebar')
@parent
@endsection

@section('contenido')

<br />
<br />
<br />
<br />
<br />

<div class="container text-center">
    <div class="row ">
        <div class="col-4 mx-auto">
            <div class="card">
                <form action="" method="POST">
                    <img src="{{ asset('images/uvm_logo.png') }}" alt="BannerHome_Compartamos" />
                    @if ($errors->any())
                    <div class="alert alert-danger" role="alert">
                        Please fix the following errors
                    </div>
                    @endif
                    {!! csrf_field() !!}
                    <div class="col-auto">
                        <label class="sr-only" for="inlineFormInputGroup">Usuario</label>
                        <div class="input-group mb-2">
                            <div class="input-group-prepend">
                                <div class="input-group-text">Usuario</div>
                            </div>
                            <input type="text" class="form-control" id="usuario" placeholder="No. de Cuenta ó E-mail">
                        </div>
                    </div>

                    <div class="col-auto">
                        <label class="sr-only" for="inlineFormInputGroup">Password</label>
                        <div class="input-group mb-2">
                            <div class="input-group-prepend">
                                <div class="input-group-text">Password</div>
                            </div>
                            <input type="password" class="form-control" id="password" placeholder="******">
                        </div>
                    </div>
                    <br/>
                    <button type="submit" class="btn btn-danger">Log In</button>
                    <br/>
                </form>
            </div>
        </div>
    </div>

</div>



@endsection