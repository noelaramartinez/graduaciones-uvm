<?php

namespace uvm\Http\Controllers;

use Illuminate\Http\Request;

class UserController extends Controller
{
    //Metodo para validar las credenciales del usuario
    public function login(){
        $user = $request->input('user');
        $pass = $request->input('password');

        $model = uvm\User::where('name', $user)
                            ->where('password', $pass)
                            ->firstOrFail();
    }
}
