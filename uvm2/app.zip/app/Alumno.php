<?php

namespace uvm;

use Illuminate\Database\Eloquent\Model;

class Alumno extends Model
{
    //
}
