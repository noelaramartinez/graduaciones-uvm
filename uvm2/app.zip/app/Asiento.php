<?php

namespace uvm;

use Illuminate\Database\Eloquent\Model;

class Asiento extends Model
{
    //
}
