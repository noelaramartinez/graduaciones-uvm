<?php

namespace uvm;

use Illuminate\Database\Eloquent\Model;

class Mesa extends Model
{
    //
}
