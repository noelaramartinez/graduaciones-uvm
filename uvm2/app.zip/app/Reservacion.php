<?php

namespace uvm;

use Illuminate\Database\Eloquent\Model;

class Reservacion extends Model
{
    //
}
