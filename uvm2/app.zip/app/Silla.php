<?php

namespace uvm;

use Illuminate\Database\Eloquent\Model;

class Silla extends Model
{
    //
}
